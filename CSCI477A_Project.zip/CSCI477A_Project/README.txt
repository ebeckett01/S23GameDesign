Done:
Add player lives and GUI
Tweak attack values to make more entertainting
Settings menu
Level 1 - Environment design
Make sure health carries over
Camera/View that follows player
Game background sprites
Enemy sprites
Score mechanic (points killing enemies) and GUI
Adjusts detection range/mechanics
Adding flee combat option
Attacking enemies when in stealth
Make a button Object
Add In tile set
Tutorial
Basic movement
Make splash screen
Moving sprites
Stealth/Hiding
Enemy attention mechanic/Stealth
Dash/double jump/parkour
Make testing level
Player sprite
Adjust player sprite collison
Added a second level


Still left to do:
Finalize the game name
Add a boss to the final level
Add a defence combat option
Adda skill tree

Likely, we will not finish the last two, but we hope to have a boss (and therefore end of game) and a game name by the full delivery. 

Some current bugs:
The player can get stuck on block or buildings on ht edge occasionally.
The player can fall off the edge
Enemies won't recognize the player occasionally if the player is above them.
